#!/usr/bin/env bash
set -euo pipefail
echo 'STAGE6_FIXTURE_RESCUE_PASS'
