#!/usr/bin/env bash
set -euo pipefail
echo 'STAGE6_FIXTURE_MPP_PASS'
